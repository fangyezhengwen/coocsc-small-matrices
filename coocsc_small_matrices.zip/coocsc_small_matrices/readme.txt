## 我们导出了两种格式：

1）row_col_value.txt
格式为：
row i: col, value; col, value; ...
row 和 col 都从小到大排序。
这个主要用于人工检查、硬件调试和 golden result 验证。

2）coocsc.npz
包含：
shape, col_ptr, row_idx, values
这个才是更接近 COO-CSC/NPU 数据流的格式。
计算方式为：
for col j:
    load x[j]
    for p in col_ptr[j] to col_ptr[j+1]:
        y[row_idx[p]] += values[p] * x[j]

summary.csv 里记录了每个矩阵的维度、nnz、稀疏度、行/列非零分布、CPU 上 COO 和 COO-CSC 的 20 次平均 SpMV 时间。CPU 时间只用于初步筛选，不代表最终 FPGA/NPU 性能。

建议优先关注：
sparsity, col_nnz_mean, col_load_imbalance, row_accum_pressure, coocsc_candidate_score。